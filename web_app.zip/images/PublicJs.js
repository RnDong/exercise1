// JavaScript Document

if($('#fdjFun').size()>0){
	$('#fdjFun').click(function(e){
		$('#searchFun').stop().slideToggle();
	});
}











